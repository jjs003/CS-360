package com.snhu.inventorymanager;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.KeyEvent;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.lifecycle.ViewModelProvider;

import com.snhu.inventorymanager.model.User;
import com.snhu.inventorymanager.viewmodel.UserViewModel;

public class RegisterActivity extends BaseActivity {

    private UserViewModel mUserViewModel;
    private EditText mUsernameEditText, mPasswordEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        mUserViewModel = new ViewModelProvider(this).get(UserViewModel.class);
        mUsernameEditText = findViewById(R.id.username_edit_text);
        mPasswordEditText = findViewById(R.id.password_edit_text);
        Button mRegisterButton = findViewById(R.id.register_button);

        // Set focus to the username field
        mUsernameEditText.requestFocus();

        // Handle the register button click
        mRegisterButton.setOnClickListener(view -> register());

        // Allow the enter button to click the register button when user has finished entering password
        mPasswordEditText.setOnEditorActionListener((v, actionId, event) -> {
            if (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER && event.getAction() == KeyEvent.ACTION_DOWN) {
                register();
                return true;
            }
            return false;
        });
    }

    // Method for registering new user
    private void register() {
        String username = mUsernameEditText.getText().toString().trim().toUpperCase();
        String password = mPasswordEditText.getText().toString().trim();

        // Check for an empty username or password
        if (username.isEmpty() || password.isEmpty()) {
            // Must enter a password AND username, clears fields and sets focus back to username field
            Toast.makeText(this, "Username and password cannot be empty", Toast.LENGTH_SHORT).show();
            new Handler(Looper.getMainLooper()).postDelayed(() -> mUsernameEditText.requestFocus(), 100);
            mPasswordEditText.setText("");
            mUsernameEditText.setText("");
        // Check if the username already exists in the database
        } else {
            User existingUser = mUserViewModel.checkForExistingUser(username);
            if (existingUser != null) {
                // Username already exists, show a toast message
                Toast.makeText(this, "User already exists", Toast.LENGTH_SHORT).show();
                // Clear fields and set focus back to username field after a small delay
                new Handler(Looper.getMainLooper()).postDelayed(() -> mUsernameEditText.requestFocus(), 100);
                mPasswordEditText.setText("");
                mUsernameEditText.setText("");
            } else {
                // Create a new User object and add it to the database
                User user = new User(username, password);
                mUserViewModel.addUser(user);
                Toast.makeText(this, "User registered successfully", Toast.LENGTH_LONG).show();

                // Navigate back to the login activity
                Intent intent = new Intent(this, LoginActivity.class);
                startActivity(intent);
                finish();
            }
        }
    }
}