package com.snhu.inventorymanager.model;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "user")
public class User {
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    private int mId;
    @NonNull
    @ColumnInfo(name = "username")
    private String mUsername;
    @NonNull
    @ColumnInfo(name = "password")
    private String mPassword;
    @ColumnInfo(name = "phoneNumber")
    private String mPhoneNumber;
    @ColumnInfo(name = "notifications")
    private boolean mNotifications;

    public User(@NonNull String username, @NonNull String password) {
        this.mUsername = username;
        this.mPassword = password;
        this.mNotifications = false;
        this.mPhoneNumber = null;
    }

    public int getId() {
        return mId;
    }

    public void setId(int id) {
        this.mId = id;
    }

    public String getUsername() {
        return mUsername;
    }

    public void setUsername(String username) {
        this.mUsername = username;
    }

    public String getPassword() {
        return mPassword;
    }

    public void setPassword(String password) {
        this.mPassword = password;
    }

    public String getPhoneNumber() {
        return mPhoneNumber;
    }
    public void setPhoneNumber(String phoneNumber) {
        this.mPhoneNumber = phoneNumber;
    }

    public boolean getNotifications() {
        return mNotifications;
    }
    public void setNotifications(boolean notifications) {
        this.mNotifications = notifications;
    }
}
