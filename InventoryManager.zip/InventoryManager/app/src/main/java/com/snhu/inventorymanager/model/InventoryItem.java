package com.snhu.inventorymanager.model;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "inventory")
public class InventoryItem {

    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    private int mId;

    @NonNull
    @ColumnInfo(name = "name")
    private String mName;
    @ColumnInfo(name = "quantity")
    private int mQuantity;
    @NonNull
    @ColumnInfo(name = "location")
    private String mLocation;

    public InventoryItem(@NonNull String name, int quantity, @NonNull String location) {
        this.mName = name;
        this.mQuantity = quantity;
        this.mLocation = location;
    }

    public int getId() {
        return mId;
    }

    public void setId(int id) {
        this.mId = id;
    }

    @NonNull
    public String getName() {
        return mName;
    }

    public void setName(@NonNull String name) {
        this.mName = name;
    }

    public int getQuantity() {
        return mQuantity;
    }

    public void setQuantity(int quantity) {
        this.mQuantity = quantity;
    }

    @NonNull
    public String getLocation() {
        return mLocation;
    }

    public void setLocation(@NonNull String location) {
        this.mLocation = location;
    }
}
