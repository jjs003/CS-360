package com.snhu.inventorymanager.repository;

import android.content.Context;

import com.snhu.inventorymanager.dao.UserDao;
import com.snhu.inventorymanager.database.AppDatabase;
import com.snhu.inventorymanager.model.User;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class UserRepository {
    private final UserDao mUserDao;
    private final ExecutorService mExecutorService;

    public UserRepository(Context context) {
        AppDatabase db = AppDatabase.getDatabase(context);
        mUserDao = db.userDao();
        mExecutorService = Executors.newSingleThreadExecutor();
    }

    public void addUser(User user) {
        mExecutorService.execute(() -> mUserDao.addUser(user));
    }

    public User getUser(String username, String password) {
        return mUserDao.getUser(username, password);
    }

    public User checkForExistingUser(String username) {
        return mUserDao.checkForExistingUser(username);
    }

    public void updateSmsEnabled(String username, boolean b) {
        mUserDao.updateSmsEnabled(username, b);
    }

    public void updatePhoneNumber(String username, String phoneNumber) {
        mUserDao.updatePhoneNumber(username, phoneNumber);
    }

    public List<User> getUsersWithSmsEnabled() {
        return mUserDao.getUsersWithSmsEnabled();
    }

    public String getPhoneNumber(String username) {
        return mUserDao.getPhoneNumber(username);
    }

    public Boolean isSmsEnabled(String username) {
        return mUserDao.isSmsEnabled(username);
    }
}
