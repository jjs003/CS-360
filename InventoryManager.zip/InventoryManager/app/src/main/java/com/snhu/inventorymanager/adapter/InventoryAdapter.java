package com.snhu.inventorymanager.adapter;

import static java.util.Locale.ROOT;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.snhu.inventorymanager.R;
import com.snhu.inventorymanager.model.InventoryItem;

import java.util.List;

// Adapter class for the RecyclerView in MainActivity
public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.InventoryViewHolder> {

    private final LayoutInflater mInflater;
    private List<InventoryItem> mItems;
    private final OnItemClickListener mOnItemClickListener;

    public interface OnItemClickListener {
        void onItemClick(InventoryItem item);
    }

    public InventoryAdapter(Context context, OnItemClickListener listener) {
        mInflater = LayoutInflater.from(context);
        this.mOnItemClickListener = listener;
    }

    @NonNull
    @Override
    public InventoryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = mInflater.inflate(R.layout.item_view, parent, false);
        return new InventoryViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull InventoryViewHolder holder, int position) {
        if (mItems != null) {
            InventoryItem currentItem = mItems.get(position);
            holder.bind(currentItem, mOnItemClickListener);
        }
    }

    public void setItems(List<InventoryItem> items) {
        mItems = items;
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        if (mItems != null)
            return mItems.size();
        else return 0;
    }

    public static class InventoryViewHolder extends RecyclerView.ViewHolder {
        private final TextView mItemName;
        private final TextView mItemQuantity;
        private final TextView mItemLocation;
        private final Button mUpdateItem;

        private InventoryViewHolder(View itemView) {
            super(itemView);
            mItemName = itemView.findViewById(R.id.itemName);
            mItemQuantity = itemView.findViewById(R.id.itemQuantity);
            mItemLocation = itemView.findViewById(R.id.itemLocation);
            mUpdateItem = itemView.findViewById(R.id.updateItem);
        }

        public void bind(InventoryItem item, OnItemClickListener listener) {
            mItemName.setText(item.getName());
            mItemQuantity.setText(String.format(ROOT,"Quantity: %d", item.getQuantity()));
            mItemLocation.setText(item.getLocation());

            mUpdateItem.setOnClickListener(v -> listener.onItemClick(item));
        }
    }
}
