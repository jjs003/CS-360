package com.snhu.inventorymanager.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.snhu.inventorymanager.model.InventoryItem;

import java.util.List;

@Dao
public interface InventoryDao {

    @Insert
    void insert(InventoryItem item);

    @Query("SELECT * FROM inventory ORDER BY name ASC")
    LiveData<List<InventoryItem>> getAllItems();

    @Delete
    void delete(InventoryItem item);

    @Update
    void update(InventoryItem item);

    @Query("SELECT * FROM inventory WHERE name = :itemName LIMIT 1")
    InventoryItem checkForExistingItem(String itemName);
}
