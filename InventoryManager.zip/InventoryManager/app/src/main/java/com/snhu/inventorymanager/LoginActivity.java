package com.snhu.inventorymanager;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.KeyEvent;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.lifecycle.ViewModelProvider;

import com.snhu.inventorymanager.model.User;
import com.snhu.inventorymanager.viewmodel.UserViewModel;

public class LoginActivity extends BaseActivity {

    private UserViewModel mUserViewModel;
    private EditText mUsernameEditText, mPasswordEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        mUserViewModel = new ViewModelProvider(this).get(UserViewModel.class);
        mUsernameEditText = findViewById(R.id.username_edit_text);
        mPasswordEditText = findViewById(R.id.password_edit_text);
        Button mLoginButton = findViewById(R.id.login_button);
        Button mCreateAccountButton = findViewById(R.id.create_account_button);

        // Set focus to the username field
        mUsernameEditText.requestFocus();

        // Handle login button click
        mLoginButton.setOnClickListener(view -> login());

        // Handle create account button click
        mCreateAccountButton.setOnClickListener(view -> {
            Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
            startActivity(intent);
        });

        // Allow the enter button to click the login button when user has finished entering password
        mPasswordEditText.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE ||
                    (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER && event.getAction() == KeyEvent.ACTION_DOWN)) {
                login();
                return true;
            }
            return false;
        });
    }

    // Method for logging a user in
    private void login() {
        String username = mUsernameEditText.getText().toString().toUpperCase();
        String password = mPasswordEditText.getText().toString();
        User user = mUserViewModel.getUser(username, password);

        // Check if the user is valid
        if (user != null) {
            // User is valid, navigate to the inventory display screen
            Toast.makeText(this, "Login successful", Toast.LENGTH_SHORT).show();
            Intent intent =  new Intent(LoginActivity.this, InventoryDisplayActivity.class);
            intent.putExtra("username", username);
            startActivity(intent);
            finish();
        } else {
            // User is invalid, show an error message and clear fields
            Toast.makeText(this, "Invalid credentials", Toast.LENGTH_SHORT).show();
            // Clear fields and set focus back to username field after a small delay
            new Handler(Looper.getMainLooper()).postDelayed(() -> mUsernameEditText.requestFocus(), 100);
            mPasswordEditText.setText("");
            mUsernameEditText.setText("");
        }
    }
}
