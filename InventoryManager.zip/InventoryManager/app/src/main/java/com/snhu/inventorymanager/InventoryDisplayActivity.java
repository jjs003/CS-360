package com.snhu.inventorymanager;

import static java.util.Locale.ROOT;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.PhoneNumberUtils;
import android.telephony.SmsManager;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.SwitchCompat;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.snhu.inventorymanager.adapter.InventoryAdapter;
import com.snhu.inventorymanager.model.InventoryItem;
import com.snhu.inventorymanager.model.User;
import com.snhu.inventorymanager.viewmodel.InventoryViewModel;
import com.snhu.inventorymanager.viewmodel.UserViewModel;

import java.util.List;

public class InventoryDisplayActivity extends BaseActivity {

    private InventoryViewModel mInventoryViewModel;
    private InventoryAdapter mInventoryAdapter;
    private UserViewModel mUserViewModel;
    private SwitchCompat mSwitchSmsNotifications;
    private static final int REQUEST_SEND_SMS = 1;
    private String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory_display);

        mInventoryViewModel = new ViewModelProvider(this).get(InventoryViewModel.class);
        mUserViewModel = new ViewModelProvider(this).get(UserViewModel.class);
        mSwitchSmsNotifications = findViewById(R.id.switchSmsNotifications);

        // Get user info from Login screen
        Intent intent = getIntent();
        username = intent.getStringExtra("username");

        // Set up previous state of the SMS notifications switch
        mSwitchSmsNotifications.setChecked(mUserViewModel.isSmsEnabled(username));

        // Set up the recycler view
        RecyclerView mRecyclerView = findViewById(R.id.recyclerView);
        mRecyclerView.setLayoutManager(new GridLayoutManager(this, 2));
        mInventoryAdapter = new InventoryAdapter(this, this::showUpdateDialog);
        mRecyclerView.setAdapter(mInventoryAdapter);

        // Set up floating action button
        FloatingActionButton mAddItemButton = findViewById(R.id.addItem);
        mAddItemButton.setOnClickListener(view -> {
            Intent intentAddItem = new Intent(InventoryDisplayActivity.this, AddItemActivity.class);
            startActivity(intentAddItem);
        });

        // Observe the inventory list from the ViewModel
        mInventoryViewModel.getAllItems().observe(this, items -> {
            // Update the RecyclerView
            mInventoryAdapter.setItems(items);
        });

        // Check for changes in the SMS Notifications switch
        mSwitchSmsNotifications.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                // Prompt user for their phone number if it hasn't been entered previously
                if (mUserViewModel.getPhoneNumber(username) == null) {
                    promptForPhoneNumber(username);
                } else {
                    // Phone number entered previously but still need to request SMS permission
                    checkAndRequestSmsPermission();
                }
            } else {
                // If user turned off switch, update database and create toast
                if ((ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) &&
                        (mUserViewModel.getPhoneNumber(username) != null)) {
                    mUserViewModel.updateSmsEnabled(username, false);
                    Toast.makeText(this, "SMS notifications disabled", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    // Method for obtaining phone number from user
    private void promptForPhoneNumber(String username) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        LayoutInflater inflater = this.getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_phone_number, null);
        builder.setView(dialogView);

        final EditText input = dialogView.findViewById(R.id.phone_number_input);

        // Handle user clicking OK button
        builder.setPositiveButton("OK", (dialog, which) -> {
            String phoneNumber = input.getText().toString();
            // Check if phone number is valid. If so, update number
            if (isValidPhoneNumber(phoneNumber)) {
                mUserViewModel.updatePhoneNumber(username, phoneNumber);
                Toast.makeText(this, "Phone number added!", Toast.LENGTH_SHORT).show();

                // Once number has been added, check SMS permission
                checkAndRequestSmsPermission();
            } else {
                // User entered an invalid number
                Toast.makeText(this, "Please enter a valid phone number", Toast.LENGTH_SHORT).show();
                mSwitchSmsNotifications.setChecked(false);
            }
        });

        // Cancel button
        builder.setNegativeButton("Cancel", (dialog, which) -> {
            mSwitchSmsNotifications.setChecked(false);
            dialog.cancel();
        });

        // Handle dialog dismiss event (user clicked outside dialog)
        builder.setOnDismissListener(dialog -> {
            // Update switch state if user dismisses without entering a number
            if (mUserViewModel.getPhoneNumber(username) == null) {
                mSwitchSmsNotifications.setChecked(false);
            }
        });

        AlertDialog dialog = builder.create();
        dialog.show();
    }

    // Helper method to validate phone number
    private boolean isValidPhoneNumber(String phoneNumber) {
        return phoneNumber.length() >= 10 && PhoneNumberUtils.isGlobalPhoneNumber(phoneNumber);
    }

    // Method for checking and requesting SMS permission
    private void checkAndRequestSmsPermission() {
        // If permission hasn't been previously granted
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            // If permission has been denied before
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.SEND_SMS)) {
                // Show an explanation to the user why the permission is needed since it has been denied in the past
                new AlertDialog.Builder(this)
                        .setTitle("SMS Permission Needed")
                        .setMessage("This app requires SMS permission to send notifications. Please allow SMS permission.")
                        .setPositiveButton("OK", (dialog, which) ->
                                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, REQUEST_SEND_SMS))
                        .setNegativeButton("Cancel", (dialog, which) -> {
                            mSwitchSmsNotifications.setChecked(false);
                            dialog.dismiss();
                        })
                        .create()
                        .show();
            } else {
                // Request permission
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, REQUEST_SEND_SMS);
            }
        } else {
            // SMS permission has already been granted
            mUserViewModel.updateSmsEnabled(username, true);
            Toast.makeText(this, "SMS notifications enabled", Toast.LENGTH_SHORT).show();
        }
    }

    // Override to customize what happens when permission is granted or denied
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_SEND_SMS) {
            boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            if (granted) {
                // User granted SMS permission, update database and make a toast
                mUserViewModel.updateSmsEnabled(username, true);
                Toast.makeText(this, "SMS notifications enabled", Toast.LENGTH_SHORT).show();
            } else {
                // User denied SMS permission, uncheck switch and make a toast
                Toast.makeText(this, "SMS permission denied", Toast.LENGTH_SHORT).show();
                mSwitchSmsNotifications.setChecked(false);
            }
        }
    }

    // Create menu with logout option
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.appbar_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    // Handle what happens when user selects logout from overflow menu
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // If logout is selected
        if (item.getItemId() == R.id.action_logout) {
            // Navigate back to the login activity
            Toast.makeText(this, "User Logged Out", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(this, LoginActivity.class);
            startActivity(intent);
            finish();
        }

        return super.onOptionsItemSelected(item);
    }

    // Method for launching the update dialog when update is clicked on an item
    private void showUpdateDialog(InventoryItem item) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_update_item, null);
        builder.setView(dialogView);

        TextView mItemName = dialogView.findViewById(R.id.item_name_dialog);
        TextView mItemQuantity = dialogView.findViewById(R.id.item_quantity_dialog);
        TextView mItemLocation = dialogView.findViewById(R.id.item_location_dialog);

        mItemName.setText(item.getName());
        mItemQuantity.setText(String.format(ROOT, "Quantity: %d", item.getQuantity()));
        mItemLocation.setText(item.getLocation());

        Button increaseQuantity = dialogView.findViewById(R.id.increase_quantity);
        Button decreaseQuantity = dialogView.findViewById(R.id.decrease_quantity);
        Button deleteItem = dialogView.findViewById(R.id.delete_item);
        Button cancel = dialogView.findViewById(R.id.cancel);
        Button save = dialogView.findViewById(R.id.save);

        // Increase quantity when user clicks increase quantity button
        increaseQuantity.setOnClickListener(view -> {
            item.setQuantity(item.getQuantity() + 1);
            mItemQuantity.setText(String.format(ROOT, "Quantity: %d", item.getQuantity()));
        });

        // Decrease quantity when user clicks decrease quantity
        decreaseQuantity.setOnClickListener(view -> {
            if (item.getQuantity() > 0) {
                item.setQuantity(item.getQuantity() - 1);
                mItemQuantity.setText(String.format(ROOT, "Quantity: %d", item.getQuantity()));
            }
        });

        // Delete item, if user confirms deletion
        deleteItem.setOnClickListener(view -> {
            // Have user confirm deletion
            new AlertDialog.Builder(this)
                    .setTitle("Delete Item")
                    .setMessage("Are you sure you want to delete this item?")
                    .setPositiveButton("Delete", (dialog, which) -> {
                        mInventoryViewModel.delete(item);
                        Toast.makeText(this, "Item deleted", Toast.LENGTH_SHORT).show();
                        dialog.dismiss();
                        cancel.performClick();
                    })
                    .setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss())
                    .show();
        });

        AlertDialog dialog = builder.create();

        cancel.setOnClickListener(view -> dialog.dismiss());

        save.setOnClickListener(view -> {
            mInventoryViewModel.update(item);
            Toast.makeText(this, "Item updated", Toast.LENGTH_SHORT).show();
            if (item.getQuantity() == 0) {
                sendSmsNotification(item);
            }
            dialog.dismiss();
        });

        dialog.show();
    }

    // Method for sending SMS notifications
    private void sendSmsNotification(InventoryItem item) {
        // Check that current user has notifications enabled
        if (mUserViewModel.isSmsEnabled(username)) {
            // Create message for item that has been reduced to zero quantity
            String message = "INVENTORY APPLICATION NOTIFICATION\nThe quantity of item " + item.getName() + " has reached zero.";
            // Retrieve a list of users that have notifications turned on
            List<User> users = mUserViewModel.getUsersWithSmsEnabled();
                if (users != null && !users.isEmpty()) {
                    // Run on background thread to avoid blocking UI
                    new Thread(() -> {
                        SmsManager smsManager = SmsManager.getDefault();
                        // For each user with notifications turned on, send message
                        for (User user : users) {
                            if (user.getPhoneNumber() != null && !user.getPhoneNumber().isEmpty()) {
                                smsManager.sendTextMessage(user.getPhoneNumber(), null, message, null, null);
                            }
                        }
                    }).start();
                }
            Toast.makeText(this, "Notifications sent", Toast.LENGTH_SHORT).show();
        } else {
            // Let user know that notifications haven't been sent because they have notifications turned off
            Toast.makeText(this, "Item quantity reduced to 0, but notifications are disabled.", Toast.LENGTH_SHORT).show();
        }
    }
}