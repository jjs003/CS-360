package com.snhu.inventorymanager.dao;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import com.snhu.inventorymanager.model.User;

import java.util.List;

@Dao
public interface UserDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void addUser(User user);

    @Query("SELECT * FROM user WHERE username = :username AND password = :password")
    User getUser(String username, String password);

    @Query("SELECT * FROM user WHERE username = :username")
    User getUserByUsername(String username);

    @Query("SELECT * FROM user WHERE username = :username LIMIT 1")
    User checkForExistingUser(String username);

    @Query("UPDATE user SET notifications = :b WHERE username = :currentUser")
    void updateSmsEnabled(String currentUser, boolean b);

    @Query("UPDATE user SET phoneNumber = :phoneNumber WHERE username = :username")
    void updatePhoneNumber(String username, String phoneNumber);

    @Query("SELECT * FROM user WHERE notifications = 1")
    List<User> getUsersWithSmsEnabled();

    @Query("SELECT phoneNumber FROM user WHERE username = :username")
    String getPhoneNumber(String username);

    @Query("SELECT notifications FROM User WHERE username = :username LIMIT 1")
    boolean isSmsEnabled(String username);
}
