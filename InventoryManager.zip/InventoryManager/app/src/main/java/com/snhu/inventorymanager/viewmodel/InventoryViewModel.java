package com.snhu.inventorymanager.viewmodel;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.snhu.inventorymanager.model.InventoryItem;
import com.snhu.inventorymanager.repository.InventoryRepository;

import java.util.List;

public class InventoryViewModel extends AndroidViewModel {

    private final InventoryRepository mInventoryRepository;
    private final LiveData<List<InventoryItem>> mAllItems;

    public InventoryViewModel(@NonNull Application application) {
        super(application);
        mInventoryRepository = new InventoryRepository(application);
        mAllItems = mInventoryRepository.getAllItems();
    }

    public LiveData<List<InventoryItem>> getAllItems() {
        return mAllItems;
    }
    public void insert(InventoryItem item) {
        mInventoryRepository.insert(item);
    }
    public void delete(InventoryItem item) {
        mInventoryRepository.delete(item);
    }

    public void update(InventoryItem item) {
        mInventoryRepository.update(item);
    }
    public InventoryItem checkForExistingItem(String itemName) {
        return mInventoryRepository.checkForExistingItem(itemName);
    }
}
