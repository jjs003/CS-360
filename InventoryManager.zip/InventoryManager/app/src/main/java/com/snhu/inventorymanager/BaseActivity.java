package com.snhu.inventorymanager;

import android.content.res.Configuration;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

// Base activity for all activities in the app
// Sets the theme based on the night mode setting
public class BaseActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        if (isNightModeEnabled()) {
            setTheme(R.style.Theme_InventoryManager_Night);
        } else {
            setTheme(R.style.Theme_InventoryManager);
        }
        super.onCreate(savedInstanceState);
    }

    private boolean isNightModeEnabled() {
        int nightModeFlags = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        return nightModeFlags == Configuration.UI_MODE_NIGHT_YES;
    }
}
