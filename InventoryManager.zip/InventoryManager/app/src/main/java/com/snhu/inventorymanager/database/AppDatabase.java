package com.snhu.inventorymanager.database;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import android.content.Context;

import com.snhu.inventorymanager.dao.InventoryDao;
import com.snhu.inventorymanager.dao.UserDao;
import com.snhu.inventorymanager.model.InventoryItem;
import com.snhu.inventorymanager.model.User;

@Database(entities = {User.class, InventoryItem.class}, version = 1, exportSchema = false)
public abstract class AppDatabase extends RoomDatabase {
    private static volatile AppDatabase mInstance;
    public abstract UserDao userDao();
    public abstract InventoryDao inventoryDao();

    public static AppDatabase getDatabase(final Context context) {
        if (mInstance == null) {
            synchronized (AppDatabase.class) {
                if (mInstance == null) {
                    mInstance = Room.databaseBuilder(context.getApplicationContext(),
                                    AppDatabase.class, "app_database")
                            .allowMainThreadQueries()
                            .fallbackToDestructiveMigration()
                            .build();
                }
            }
        }
        return mInstance;
    }
}
