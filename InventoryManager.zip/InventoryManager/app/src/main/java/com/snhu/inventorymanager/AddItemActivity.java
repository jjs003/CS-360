package com.snhu.inventorymanager;

import android.os.Bundle;
import android.view.KeyEvent;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.lifecycle.ViewModelProvider;

import com.snhu.inventorymanager.viewmodel.InventoryViewModel;
import com.snhu.inventorymanager.model.InventoryItem;



public class AddItemActivity extends BaseActivity {

    private EditText mNameEditText;
    private EditText mQuantityEditText;
    private EditText mLocationEditText;

    private InventoryViewModel mInventoryViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        mNameEditText = findViewById(R.id.item_name_edit_text);
        mQuantityEditText = findViewById(R.id.item_quantity_edit_text);
        mLocationEditText = findViewById(R.id.item_location_edit_text);
        mInventoryViewModel = new ViewModelProvider(this).get(InventoryViewModel.class);

        Button saveButton = findViewById(R.id.save_item_button);
        Button cancelButton = findViewById(R.id.cancel_button);
        saveButton.setOnClickListener(view -> saveItem());
        cancelButton.setOnClickListener(view -> finish());

        // Set focus to the item name field
        mNameEditText.requestFocus();

        // Allow the enter button to click the save button when user has finished entering the item location
        mLocationEditText.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE ||
                    (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER && event.getAction() == KeyEvent.ACTION_DOWN)) {
                saveItem();
                return true;
            }
            return false;
        });
    }

    // Method for saving a new item
    private void saveItem() {
        String name = mNameEditText.getText().toString().trim();
        String quantity = mQuantityEditText.getText().toString().trim();
        String location = mLocationEditText.getText().toString().trim();

        // Ensure that all fields are filled out
        if (!name.isEmpty() && !quantity.isEmpty() && !location.isEmpty()) {
            // Convert name and location to sentence case
            name = toSentenceCase(name);
            location = toSentenceCase(location);
            // Make sure that item doesn't already exist
            if (mInventoryViewModel.checkForExistingItem(name) == null) {
                // Create new item object and insert into database
                InventoryItem newItem = new InventoryItem(name, Integer.parseInt(quantity), location);
                mInventoryViewModel.insert(newItem);
                finish(); // Close activity after saving
            } else {
                // Item already exists
                Toast.makeText(this, "Item already exists", Toast.LENGTH_SHORT).show();
            }
        } else {
            // User did not fill out all fields
            Toast.makeText(this, "Please fill out all fields", Toast.LENGTH_SHORT).show();
        }
    }

    // Helper method to convert a string to sentence case
    private String toSentenceCase(String input) {
        if (input == null || input.isEmpty()) {
            return input;
        }

        // Convert the first character to uppercase and the rest to lowercase
        return input.substring(0, 1).toUpperCase() + input.substring(1).toLowerCase();
    }
}