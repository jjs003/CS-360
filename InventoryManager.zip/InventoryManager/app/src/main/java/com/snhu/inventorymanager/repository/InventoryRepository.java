package com.snhu.inventorymanager.repository;

import android.app.Application;

import androidx.lifecycle.LiveData;

import com.snhu.inventorymanager.dao.InventoryDao;
import com.snhu.inventorymanager.database.AppDatabase;
import com.snhu.inventorymanager.model.InventoryItem;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class InventoryRepository {

    private final InventoryDao mInventoryDao;
    private final LiveData<List<InventoryItem>> mAllItems;
    private final ExecutorService mExecutorService;

    public InventoryRepository(Application application) {
        AppDatabase db = AppDatabase.getDatabase(application);
        mInventoryDao = db.inventoryDao();
        mAllItems = mInventoryDao.getAllItems();
        mExecutorService = Executors.newSingleThreadExecutor();
    }

    public LiveData<List<InventoryItem>> getAllItems() {
        return mAllItems;
    }

    public void insert(InventoryItem item) {
        mExecutorService.execute(() -> mInventoryDao.insert(item));
    }

    public void delete(InventoryItem item) {
        mExecutorService.execute(() -> mInventoryDao.delete(item));
    }

    public void update(InventoryItem item) {
        mExecutorService.execute(() -> mInventoryDao.update(item));
    }

    public InventoryItem checkForExistingItem(String itemName) {
        return mInventoryDao.checkForExistingItem(itemName);
    }
}
