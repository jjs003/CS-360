package com.snhu.inventorymanager.viewmodel;

import android.app.Application;
import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;

import com.snhu.inventorymanager.model.User;
import com.snhu.inventorymanager.repository.UserRepository;

import java.util.List;

public class UserViewModel extends AndroidViewModel {
    private final UserRepository userRepository;

    public UserViewModel(@NonNull Application application) {
        super(application);
        userRepository = new UserRepository(application);
    }

    public void addUser(User user) {
        userRepository.addUser(user);
    }

    public User getUser(String username, String password) {
        return userRepository.getUser(username, password);
    }
    
    public User checkForExistingUser(String username) {
        return userRepository.checkForExistingUser(username);
    }

    public Boolean isSmsEnabled(String username) {
        return userRepository.isSmsEnabled(username);
    }

    public String getPhoneNumber(String username) {
        return userRepository.getPhoneNumber(username);
    }

    public List<User> getUsersWithSmsEnabled() {
        return userRepository.getUsersWithSmsEnabled();
    }

    public void updateSmsEnabled(String username, boolean b) {
        userRepository.updateSmsEnabled(username, b);
    }

    public void updatePhoneNumber(String username, String phoneNumber) {
        userRepository.updatePhoneNumber(username, phoneNumber);
    }
}
